(function(){
  'use strict';
  /* ---------- Tema gelap / terang ---------- */
  var KEY='nb-theme', root=document.documentElement, themeBtn=null;
  function store(k,v,sess){try{var s=sess?sessionStorage:localStorage;if(v===undefined)return s.getItem(k);s.setItem(k,v)}catch(e){return null}}
  function cur(){var s=store(KEY);if(s==='dark'||s==='light')return s;return window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'}
  var SUN='<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4.5"/><g stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M12 2.5v2.4M12 19.1v2.4M2.5 12h2.4M19.1 12h2.4M5.3 5.3l1.7 1.7M17 17l1.7 1.7M5.3 18.7L7 17M17 7l1.7-1.7"/></g></svg>';
  var MOON='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.5 14.2A8.6 8.6 0 0 1 9.8 3.5 8.6 8.6 0 1 0 20.5 14.2z"/></svg>';
  function apply(t){
    root.setAttribute('data-nb-theme',t);
    if(themeBtn){themeBtn.innerHTML=t==='dark'?SUN:MOON;var l=t==='dark'?'Pakai mode terang':'Pakai mode gelap';themeBtn.setAttribute('aria-label',l);themeBtn.title=l}
  }
  apply(cur());

  /* ---------- Bahasa Indonesia ---------- */
  var D={
   'overview':'Ringkasan','settings':'Pengaturan','application api':'API Aplikasi','management':'Manajemen','databases':'Database',
   'locations':'Lokasi','nodes':'Node','servers':'Server','users':'Pengguna','roles':'Peran','service management':'Manajemen Layanan',
   'mounts':'Mount','nests':'Nest','eggs':'Egg','administration':'Administrasi','a quick glance at your system.':'Ringkasan singkat sistem kamu.',
   'system information':'Informasi Sistem','get help':'Bantuan','support the software':'Dukung Software','create new':'Buat Baru',
   'save':'Simpan','save changes':'Simpan Perubahan','delete':'Hapus','edit':'Ubah','cancel':'Batal','close':'Tutup','create':'Buat',
   'update':'Perbarui','search':'Cari','name':'Nama','description':'Deskripsi','status':'Status','actions':'Aksi','created':'Dibuat',
   'username':'Username','password':'Kata Sandi','login':'Masuk','logout':'Keluar','sign out':'Keluar','forgot password?':'Lupa kata sandi?',
   'remember me':'Ingat saya','account':'Akun','account overview':'Ringkasan Akun','console':'Konsol','files':'File','schedules':'Jadwal',
   'backups':'Cadangan','network':'Jaringan','startup':'Startup','activity':'Aktivitas','start':'Mulai','restart':'Mulai Ulang',
   'stop':'Hentikan','kill':'Paksa Berhenti','address':'Alamat','cpu load':'Beban CPU','memory':'Memori','disk':'Disk','uptime':'Waktu Aktif',
   'offline':'Offline','running':'Berjalan','starting':'Memulai','stopping':'Menghentikan','your servers':'Server Kamu','all servers':'Semua Server',
   'other servers':'Server Lainnya','new file':'File Baru','new folder':'Folder Baru','upload':'Unggah','rename':'Ganti Nama','move':'Pindahkan',
   'permissions':'Izin','archive':'Arsipkan','unarchive':'Ekstrak','download':'Unduh','create backup':'Buat Cadangan','create database':'Buat Database',
   'create schedule':'Buat Jadwal','create user':'Buat Pengguna','new user':'Pengguna Baru','new server':'Server Baru','new node':'Node Baru',
   'new location':'Lokasi Baru','email':'Email','email address':'Alamat Email','first name':'Nama Depan','last name':'Nama Belakang','language':'Bahasa',
   'general':'Umum','advanced':'Lanjutan','mail':'Email','frontend':'Tampilan','reset password':'Atur Ulang Kata Sandi','details':'Detail',
   'build configuration':'Konfigurasi Build','manage':'Kelola','view':'Lihat','owner':'Pemilik','connection':'Koneksi',
   'yes':'Ya','no':'Tidak','enabled':'Aktif','disabled':'Nonaktif','confirm':'Konfirmasi','submit':'Kirim','back':'Kembali','next':'Lanjut',
   'loading...':'Memuat...','no results found.':'Tidak ada hasil.','server name':'Nama Server','server owner':'Pemilik Server',
   'api credentials':'Kredensial API','ssh keys':'Kunci SSH','two-factor authentication':'Autentikasi Dua Faktor',
   'there are no servers associated with your account.':'Tidak ada server di akun kamu.','suspend':'Suspend','unsuspend':'Buka Suspend',
   'reinstall':'Instal Ulang','delete server':'Hapus Server','toggle install status':'Ubah Status Instal','power':'Daya','variables':'Variabel',
   'docker image':'Image Docker','startup command':'Perintah Startup','port':'Port','allocations':'Alokasi','primary':'Utama','make primary':'Jadikan Utama',
   'last modified':'Terakhir Diubah','size':'Ukuran','type':'Tipe','minute':'Menit','hour':'Jam','day of month':'Tanggal','month':'Bulan',
   'day of week':'Hari','next run':'Jalan Berikutnya','last run':'Terakhir Jalan','active':'Aktif','inactive':'Tidak Aktif','sign in':'Masuk',
   'send email':'Kirim Email','return to login':'Kembali ke Login','welcome back':'Selamat datang kembali','administrator':'Administrator',
   'login to continue':'Masuk untuk melanjutkan','username or email':'Username atau email',
   /* server disuspend dan status server */
   'server suspended':'Server Disuspend',
   'this server is suspended and cannot be accessed.':'Server ini disuspend dan tidak bisa diakses. Hubungi Telegram @csfizcloud.',
   'suspended':'Disuspend','installing':'Menginstal','server installing':'Server Sedang Diinstal',
   'your server should be ready soon, please try again in a few minutes.':'Server kamu segera siap, coba lagi beberapa menit lagi.',
   'server installation failed':'Instalasi Server Gagal','server transferring':'Server Sedang Dipindah',
   'your server is being transferred to a new node, please check back later.':'Server kamu sedang dipindah ke node baru, cek lagi nanti.',
   'restoring backup':'Memulihkan Cadangan',
   'this server is currently being restored from a backup and its filesystem is unavailable. please check back in a few minutes.':'Server sedang dipulihkan dari cadangan dan file belum bisa diakses. Cek lagi beberapa menit lagi.',
   'this server is currently running its installation process and most actions are unavailable.':'Server sedang menjalankan proses instalasi, sebagian besar aksi belum tersedia.',
   /* dashboard dan konsol */
   'showing your servers':'Menampilkan server kamu','showing other\'s servers':'Menampilkan server pengguna lain',
   'there are no other servers to display.':'Tidak ada server lain untuk ditampilkan.',
   'network (inbound)':'Jaringan (Masuk)','network (outbound)':'Jaringan (Keluar)','inbound':'Masuk','outbound':'Keluar',
   'memory usage':'Pemakaian Memori','cpu usage':'Pemakaian CPU','type a command...':'Ketik perintah...',
   /* file */
   'create directory':'Buat Folder','directory name':'Nama Folder','file name':'Nama File','modified':'Diubah','select all':'Pilih Semua',
   'new directory':'Folder Baru','save content':'Simpan Isi','upload files':'Unggah File','this directory seems to be empty.':'Folder ini kosong.',
   /* database */
   'new database':'Database Baru','database name':'Nama Database','connections from':'Koneksi Dari','endpoint':'Endpoint','host':'Host','database':'Database',
   /* jadwal */
   'last run at':'Terakhir Jalan','next run at':'Jalan Berikutnya','schedule name':'Nama Jadwal','new task':'Tugas Baru','tasks':'Tugas',
   'edit task':'Ubah Tugas','run now':'Jalankan Sekarang','delete schedule':'Hapus Jadwal','action':'Aksi','payload':'Isi',
   'send command':'Kirim Perintah','send power action':'Kirim Aksi Daya','time offset (in seconds)':'Jeda Waktu (detik)',
   /* pengguna, cadangan, jaringan, pengaturan */
   'remove':'Hapus','2fa enabled':'2FA Aktif','backup name':'Nama Cadangan','ignored files & directories':'File & Folder yang Diabaikan',
   'locked':'Terkunci','restore':'Pulihkan','lock':'Kunci','unlock':'Buka Kunci','notes':'Catatan','ip address':'Alamat IP',
   'add allocation':'Tambah Alokasi','sftp details':'Detail SFTP','server address':'Alamat Server','debug information':'Informasi Debug',
   'server id':'ID Server','change server name':'Ganti Nama Server','reinstall server':'Instal Ulang Server','launch sftp':'Buka SFTP',
   /* akun */
   'update password':'Perbarui Kata Sandi','current password':'Kata Sandi Saat Ini','new password':'Kata Sandi Baru',
   'confirm new password':'Konfirmasi Kata Sandi Baru','update email address':'Perbarui Alamat Email','create ssh key':'Buat Kunci SSH',
   'public key':'Kunci Publik','create api key':'Buat Kunci API','last used':'Terakhir Dipakai','allowed ips':'IP yang Diizinkan','api key':'Kunci API',
   /* admin */
   'basic administration':'Administrasi Dasar','dashboard':'Dasbor','server list':'Daftar Server','create server':'Buat Server',
   'database hosts':'Host Database','configuration':'Konfigurasi','allocation':'Alokasi','admin':'Admin','index':'Indeks'
  };
  var SKIP='script,style,textarea,pre,code,.xterm,[class*="Terminal"],[class*="FileObjectRow"],.nb-dock,#nb-help,.nb-expiry,[contenteditable]';
  function tr(s){
    var t=s.trim(); if(!t||t.length>60)return s;
    var v=D[t.toLowerCase().replace(/\s+/g,' ')];
    return v?s.replace(t,v):s;
  }
  function addContact(p){
    if(!p||!p.appendChild||(p.querySelector&&p.querySelector('.nb-contact')))return;
    var a=document.createElement('a');a.className='nb-contact';a.href='https://t.me/csfizcloud';a.target='_blank';a.rel='noopener';
    a.textContent='Buka Telegram @csfizcloud';p.appendChild(a);
  }
  function walk(n){
    if(n.nodeType===3){
      var p=n.parentNode; if(p&&p.closest&&p.closest(SKIP))return;
      var r=tr(n.nodeValue); if(r!==n.nodeValue)n.nodeValue=r;
      if(n.nodeValue.indexOf('@csfizcloud')>-1)addContact(p);
      return;
    }
    if(n.nodeType!==1||(n.matches&&n.matches(SKIP)))return;
    ['placeholder','title','aria-label'].forEach(function(a){
      if(n.hasAttribute&&n.hasAttribute(a)){var o=n.getAttribute(a),r=tr(o);if(r!==o)n.setAttribute(a,r)}
    });
    for(var c=n.firstChild;c;c=c.nextSibling)walk(c);
  }
  var queued=false;
  function run(){queued=false;if(document.body)walk(document.body)}
  function sched(){if(!queued){queued=true;(window.requestAnimationFrame||setTimeout)(run)}}

  /* ---------- Musik latar ---------- */
  var LOCAL='/finzz/music.mp3', REMOTE='https://www.upload.ee/download/19846438/7ebdbf9bb6e32356a639/file.mp3';
  var want=store('nb-music')!=='off', fell=false, audio=null, musicBtn=null;
  function unlock(){
    var ev=['pointerdown','touchstart','keydown','click'];
    function go(){ev.forEach(function(e){document.removeEventListener(e,go,true)});if(want&&audio.paused)audio.play().catch(function(){})}
    ev.forEach(function(e){document.addEventListener(e,go,true)});
  }
  function play(){var p=audio.play();if(p&&p.catch)p.catch(unlock)}
  function initMusic(){
    audio=document.createElement('audio');audio.loop=true;audio.preload='auto';audio.volume=.35;audio.src=LOCAL;
    var t=parseFloat(store('nb-music-t',undefined,true)||'0');
    audio.addEventListener('loadedmetadata',function(){if(t>0&&t<audio.duration-1)try{audio.currentTime=t}catch(e){}},{once:true});
    audio.addEventListener('timeupdate',function(){store('nb-music-t',String(audio.currentTime),true)});
    audio.addEventListener('error',function(){
      if(!fell){fell=true;audio.src=REMOTE;audio.load();if(want)play()}
      else{musicBtn.classList.add('err');musicBtn.title='File musik tidak ada di server. Jalankan finzz_music.sh'}
    });
    audio.addEventListener('playing',function(){musicBtn.classList.add('on')});
    audio.addEventListener('pause',function(){musicBtn.classList.remove('on')});
    document.body.appendChild(audio);
    musicBtn.onclick=function(){if(audio.paused){want=true;store('nb-music','on');play()}else{want=false;store('nb-music','off');audio.pause()}};
    document.addEventListener('visibilitychange',function(){if(document.hidden)audio.pause();else if(want)play()});
    if(want)play();
  }

  /* ---------- Dock, tombol Bantuan, mulai ---------- */
  function build(){
    if(!document.body||document.querySelector('.nb-dock'))return;
    var dock=document.createElement('div');dock.className='nb-dock';
    themeBtn=document.createElement('button');themeBtn.type='button';
    themeBtn.onclick=function(){var n=cur()==='dark'?'light':'dark';store(KEY,n);apply(n)};
    musicBtn=document.createElement('button');musicBtn.type='button';musicBtn.setAttribute('aria-label','Musik latar');musicBtn.title='Musik latar';musicBtn.id='nb-music';
    musicBtn.innerHTML='<i></i><i></i><i></i>';
    dock.appendChild(themeBtn);dock.appendChild(musicBtn);document.body.appendChild(dock);
    var h=document.createElement('a');h.id='nb-help';h.href='https://t.me/csfizcloud';h.target='_blank';h.rel='noopener';h.textContent='Bantuan';
    document.body.appendChild(h);
    apply(cur());initMusic();
  }
  function start(){
    build();run();
    try{new MutationObserver(sched).observe(document.body,{childList:true,subtree:true,characterData:true})}catch(e){}
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
(function(){try{var l=document.querySelector("link[rel~=icon]")||document.createElement("link");l.rel="icon";l.href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAi7UlEQVR42sWbd9hcVbX/P+uUqe+8veVNr5AASUyiBAgB6dwrkSp6AyJeFKUIRLEhgiIiCKGICAoI/EClBUQjLYAYQ4QEkhDSSE/elre3aafs9fvjTEJE5Xqveu95nv2cmTMze/Zae+1Vv8vmn39ZgA3XAK/qvqcCfB6XThqw3DG4sQm49kQsZywpdxhpqaA+YXO2X+QtzJ9PeY0Fr9qlN/rPXKz8cwk/S+DxcN/MTckR9NgfJm/NBncauGMhWSckylRiLmKVSDKgng/+EBQ6wduOeGtIBH+iOlxBa775PbLPsuFxhfcz6f+OAX9OeHVyOFn3VIqx0yF9KG5jmmETYNwEmDAWGTccbaqFyjJIuIoIFH2Rviza2g3b2+DdbbB1G7RvA681C4OvEy8sIl18mp58yz+TEfIP/tYCIsIrUjMZil9EmDldUuMrOXgmesyRcOyskClNSjmCj0hfUejuRweyIgUvkuhEDMpTSk0FWpVU4igDKGvbhZfesnlpObLuDTS3tQ9nYBFp7y76+98srcMuMUH/Nxlg7eN8VfogBtyrJKw7m+GzLD3l32D+ySGH1MAgFqvfFVm+Gt7eCLtaoLsLcjkIAtQoiAViI24M0mVQWwNjRsD0Sejhh8C08Uoaw8ou5KEXbBY/h7avNDhdjxLPXU82u+4v1vQvZoADBIwgSWfFVVKsWkDTEUnO/xT6n/8eUo4lf9goPL0Elq+EtmbwcmAb1I72a9/RFxCs0oOS7gyB0ILQhngGRo6EuTPgtLno7DFKmzHctdiWRx5H9yzPk+xdSE339TST37e2fyEDbCCkvPojDDj3SPKQ6ZxzHvq1c0My2PxqKfLwk7DhHQjz4Co4BjQEE4CGqAkRFEUAQUoSEA0LLBssFywHcCNmeBbEymD6wXD+Keip02G3F8p3f2Hz5CNo+M5q0rkLGRh4Y98a/8kMkNIwJKu+QL7idjnk1Jj+8MsBs0fY8sQq4a4HYcMa1CpCHNAAwiJifDDhviOqlo3YbkSkuKUjYEXTK2gYIntXJRaIgB0DiUER0ATMmAkL5qPHj1We2hzyzdsdtv/Oo6zvMoZ67y6Jk/49esH+u4kXDPGaW6Q49nr5jyssfeibBt9x5PLbhLvvgd7dkAgRKYCfg7AAxosYQYkINwUmCV4aggxoRTSCDIRpkBSSSILjRjSoRiYy9KK5XI1GczP8ZhmyJSece4zF/BNCWY/Dxm0fIxmUE+SfLzHhH5aA94h3638u1tTPcPW3Ar3kKFseXi3cdAt07oCUHYl8UADjo7rfMbRcxE2jxRhYFbhjxpCadiDpyWOwh9VCzCEc9Cju7Ca/roXCht2YgW4klgUzBH4WTBHUjxgiFjhxsBKQExh3MPq9y2DucOUrT4bce5NDfPMDFHrP/3skQT6Y+KNs5NUAt+EBiX3kPG673tfTDnHlu7+G++8CuxCdcS+LGg/RMDrnAOKAkwRSEFZgH34o6XNPJHH8DNwG570/DiM53KsGvbe66X9kJbnfvIXm2xGrBwq9EEaMUC35WeKAmwbfglgtfP1y9POzkOte9PWm77i4Gx+k2P2ZkmIM/xYTPoABRznwakC85haxP7KAu27x9cTJLl95EBbdj6SIxDIsggaoCSIrpBoRHyuDsAxqJmAtmI/72bnYKTBvtqG/X4VZuwXT3ot4PiTj2KMaiM8+iMRJM7EaEuSWdjB07RLMlnWI1QH5TgiGUFNA1C/RIxGT1QU/BZdejn7jo8h1S3y96SqXxLsLyfd9+YOsg3ygtk/Vfl68A+/h5tt8/dRMVy57EH59L5p2kCAfMWCvD6KKaonJbgoJy2DcTLj5cpjTBEu3ofc8CstWw8BA9DunpORUIm1vu8jwRtxPn4y94BTCjgD/khfQNasRmiHfgQYDEOYQU4ysCwJ2HKwkeEn0kivhG0fBFU/63Pdtl1TLheT6f/q3rIP9N52c2ooZ9A9bxEVXw5c+asu3nhYe+wmk7RLx/n6a2kGdJDipSNGFLjQdDLdcBRMa4KZfwTe/j6xbh9gFJBaCEyC2j1gB4iiSECRuwWCWcMlKgtd3YD42C46ZCH/MQS6MLGVJJaGmxHxTUrQBOCCvr4TEFLjyGIsVecPm1SeTChbj+6376YS/yQCBsyyOWh+XDQ3PytzPNnLHBcpPV1pyz42Q0EjZ7VVylos6abDKICgDKoFKJFYNVyyAMaOR790O992BxAJwffCzaJAHUzKRGkQ+gvEh8BFbkUwK2dgMK9rg9COQ+npklQd2Mjrzlo2IlqyMFyne0hEUS5E31sIBc4Tz5yrPbHLo3TqHUfn76f9LT/F9DDjLhsdDWmuuleqjztD7rwvYmHXk2m+jph/R/bWxi8Yy4KWRzChk9lFw0slwzEnI3JNg5ATkwV/BEzcgFQnUGwAvGxFqgsg3UINoyVEKQ0QMagLU89CyZBQYdQjMmQmjy2HqJKiZBP2C5rrB6wF/sLSm0lG0bcTLI6tb4OMnWEyeFPCb5Y3k+oTQe6lEs/41BliwXqnNTJKhEf+Pr10jfOQAW65cKDSvQlzQsICoQcUBNwN+OTLnWLjsC+hpx8D4seBWQk6Q1zegi74ambLsHlxRnJiFZYFtS8nHUdRSEBDXRgMfQo94DKywgJNQ7O1bsV59A3vlMpyNq7FzPdhONVZhENfbgSN5Qt9DRPY5UxKLQVc7dGbgkrnCZt+w7o3ZZPQxPK97/6Mgf7b78ngIdY/J1E+fpU/fHMhdyxx+8m1IEomu8aOfuGVIUAGfOgf9xFkwBPLqS7D0edi9Cc11IeEgWugiUZEm8+XLCWcfRegkUUswtkUgSmhBoAppC9ncTPyCi3n+6XsZObKJMAgQq7Q/QRi5yqqRBDkx1Eli/CFOmnce2zZvw0pkMEQutVhxcDIg9egPb4HJZYGc9BlHh5Y8TtD/if0VovOeJDweUpGeKgMjzuCi8wy7AocnHgQnhLB0VlFw4kjBho+dgJ5xFrzTjzx8A7rmVbBCsA2iOTTI4qZjpH/xKD0fmkHYWWK3Hbn4xEr/ruA0QnDL3cw/4XCOnPPhvzswueVHv2Xbhu041cMIxI3+ICz5IYSI14nc9yj6wGWOfvJsw90rzqAyN5U+/+29TCi5i2dFi+tLXMG0Yyw99hAjD78MnZvBtcCEUfBiOZHNHTEOPXU+rC8iP70W1rwMaRdiCpoHCaDYQ+zCL9IzdQbhpgKSDbByAbJ3ZANk0ENCH7O6lfhTT/HVb38ZYwy+7xOG4X7D7LsXix5haNj07jau+uZCrPQ4TNiI+E0QNECsDmKZSMDjNqx7DX63C/v8U4xUzbAYjF3xfpNnweMho2iEujP55GlKKzYvPx3tlCmJn5NEJIn0BejsI0EqkcVPwLY3IJNB/CHwhxAtovlBrGGj8M66AN3qRyGvr6inkTsSAJ6CZ2HXu5gf3MhZHz2MiQdOwPd9RAQt+RXRMPvu8XgM27a4+PKrKXoO8qWFmHvvRK//Ksw7HcqmQFAfMUEETBYWPYtVk7DjJ5ykhJkzqUs1lo6AZcFRkRTsTp8hww4pk+MOC3nhbaFjM+o4KFbkZOQdqB4BJ/wbHHw0bCzCxlcgWY6GQckvixQaYQ6++g38phpIumhFDK1w0WoXKp1oVLhIlYPe+TCZ3z3DD+68EYB4PI7jOH9ztLV3ct7nvsVLzy/HnjSDMGxH8r1w0jS47z/gl1fC8SeBX4daCTTuIhvfInhrSGJnnhyKM6qMAT1jrwA4cLTBehVM+szY4YdrmLLEvPoSiA8Sj0TeiiHnnoYe9XHQWmgGtqxDs4MQCvgBBF6k0VWRZCX63Avw0u8jxbVX29o26hWhWIwUdlsrbFiJl27gPz+/gCAMEUBLGYPI7dn73gYrwep3dtG7qxur6kDC3bvg9hshlkTqamHesegV8+En8+G6WuShxyCZg6Fu9MUVcOVHJTZ+uhY3rT8T4cfoNSayArUMo2vy1vSPHkrmx0xXvfACwWuPTocTRy/7MkydAxtCZNkS9N03kMF2nJRQPm0msfGjaPvtImTHH9BcRxTre/l9brLsI6iflNSQGj4MS2xsx8ZJl0EYMDQwhCWCiJRM017iIx1tOXH27OyBmsnYB8yh4shZxHr66V76CkFPM+rnIVtADj4Ibvk6OqkBrvwFLF6MuD46ajaJBxZofOH90n//1/Op2uz4XFeuLbICvcnZVtXYZDjtkNC8vNmWwT2QjkGhCOd/EUbPgRd3IUvuR9vXY1VV406ejt00k0LFODTeBr4LE+dB9yakay0qppT4sNEwwNWQiZd/Dc6ez2DVMERsUigZNdQKjHBthtkwzIFGG+psoc6BlAkZkXL45aLn+fT5P0QmfZQg20NYVIqT/g1XR6EbX8HsWoE6Bjasg8tvhLuvgy98HFa9DZ27oH0X3hZfUofPCrm/JpnL9s8GnrKjPE/qs86UY4/Q+R8z5vFXLNm6AsIQZhyBzv1PWN2G/O5OyHdi1Y/GqpkI0kiQddAwxPjt+K/ch/RvQ6wkJEchbjl4gxB62EGOg+64k44vXMiOXAUDWYv+vNBVEFo9iy2B0ONB3gcvhFBLO68Qc4R8vsg5n76GngEQHcLsegerZjzxpgOpPrCCvMmgRQeCHEgBWlog68KxH4b+AFatRUyATpxKatZo4z32G0vzu3aBedGK5C02zR4/HnyEHVvBEnBd9KDToQ3446NQ7EcqhkE6ick4hN1boXUpsvu3hBtWgBNEym9oJzjdaJBH0sPRQo5Rp59O55ln0fFOESsbYAUmGr5iewbbNwyGIQN+yGBp9HshHTkPSVjceMvD7Fi7GruqnDARg4SNadvC0NKnaHnqOUy2Ew2SSLwBEg1oyoXfvwyrh+CgjyCZcvDzsHkHYU1K3MZRoPY0BBx+gsuFibH22NH4/Qg97ZHpqxoNiYOjIkXrymhHDGCXwebNWLaFUz+eeNNUrGqX4rb1EPZBfg+Kj9gOZnAnjiPEz/k825sVCS20aEXqzYoqQgYL0jbdFsQdyJRGyoWmGpclr27nZzf/DCtdhhay2G45OuzDlH3oGDRdS/+fXkI3vAxBMXLYwiIiPtrfDm+shUMPQ2vqkd522N1CoIgzvAm2WGNnfg7X4XpqIVkXDmvA9CKS70cJIT0KfEFaVoPfAxJCezvS7mBVjsGqnIQpJvE68jhWFnrWQKoeEsNhMAdBGxT7qJ17JN2TZsIOA469XyyqaMqhLAmZjq2UWyGVlpC2ldAW+rXI08vW8sSt9+HbLlbT4UiyHi3mMK3rybceSHz6TMqPO4XB5VWYHcvQvrZop00ekRS6YwdMOQySlVHA1NeN8RC3sQGI1W1YlKt16HZrRJJlflUV9GcFLxc5EFIJA4q2boeurZCoRurGQjKDqRiOaV0DKphUJUF/OkqNNdRAVxuIQe0yLDWk/uOz7OgSJB8xAAExBk3aVLRvQm64lL4Nm+hD2KmwRiO74QeK8SyoHIVVNQWTzaHZTUhlOdCP19ZCKEuJTayGsVXojhooCyHXjnZ2gF+EPQPQScmUG8j2Y3zErq4BnDI/dGscQi3HTjomnUE7C4jxI/NTGMStEVLzZhLrPxd/4wb6Nw5haoYhg5sh34qVSOFUD0dDP9JcHTvAsZBMLbr7bSqmHEh2+omYLQZxbNSL/AE1QrzcEFy/gOybSyHRUApn5b34zElipysxlosZbIYwgGQZ9BXArcCKWViFXQw+thjx94BtoYN9WF4/8SmjsOpGEI4cg9cL2tMNlkIxi/ogZWnAcTTQcgfVBJYNtqOERtTPgmvD4YdixntknSMoZo4mc46h6e3n6bz2W/jUYQ+fjSQbkEQtUmFg4zIwGTSfRwa3QdhN+hNfo703DgM+Gi9lPkMDVQ6xt5cxtGolkm6MnonsK5OBDU6GkCQYBTFQVo1UjIRUEwz2Qu2BaNUEHFOP7llDuGMpTr1F4qrrMWNmE+biUAix+yB4MwM7+6MEigFxbQVL1GjC2VeeNgYcF/H60cO/COWTCV/fBCIEMZdCppL44ScT/1YZ/o33YAY70P49mGQl9KcgaIdMAsmHqHFIDRuBN/tsgs2KGAsNSuk/H9xhECx+tJRJTkXOolhggijpIqWqkMQgOQKpmoKm6qHQhXZuht5NBKkMJCvR6U3obzcg9aPQW69lqH84PNsFuT0RXSkHjpwPbRtgsKeUHi0lcHFwECkQeki+IMTi0DQXnFGw9rUoU+M4EE8hQwMUX/AozjgSabgHXfsSpMsxdhKSDZHTUzMBOrdCzxuUffqr9GVroNuHZGn3/RDKXaRtB8WlSyBeBloqhxkPksPRqlmQqItSXX3bgAQ6uAc6N6LJNJIsQ13QttXo7jehwoH2nfCZCwh3Dofl6xCvF83nkDCImJuuQsceDztWRmmFbF4gQKyw4JCUAS3kAruv2wkbR0FqODSviUJaNWC7EM+gQ9WQ9WFtIzpsDmLXo4kksns12rkOwYd1v0FtFzdTh5lzLt4GgwSKZsPoHnOxRkFw212YfA+SrogqxCaAqhkwfB645WCnIV4NjT68ey8MbAAnAUOd6EAeKfTAMBs58TMQG4PuakeZDH9cD53votkeKAyiYUnpOEnEgDZOx3bA9PQBQSBGBhwyfje9uSG7vbPSTBA1wYDIYCtqR6UpsV3UKYNsH2SL4MUgeSI67hxIlqHje2H5V9BdLyBlNdC/i9Rx8xj0D4A9QGUMYqCNIHV59Oc/QV9+HDI1YGci5yXdABWT0UIn5FoQiaF2BjITYNQ86F4G8WHQtxb6NkJlNZxyI5ofD7u7QMtg03bItsNQJ3i9SJBFg2IUobopKBSg7kisOBq0tQv4Q27S7XY4iS5+WuxkV3OlVY6aRFzobkVicdQYsBwsux+8/qhCM9iCuvWQbIJ4FaSbYMIVSM8GtNiNFU9izb8EzwqQAzqQsAfJtsH6d+GlV9ANK6Ksr1OOxuqQeDUQQ3s3IiYoRY8W4qTRQltkISpnQXEQMpMh14KOPgLe7ogYE7Mjux/koDgAfn9URQryUQFFAT8G2QI0VBMDzbW2CZjO3Oh8l8PP8KGwPdy+Y6ImUOobYWsvSBrREBUL9WzQXrA6wE6BUx6dU6eyVJRw0fI50LsMXKHvrhvQjlYY6EEHBiFfLMV1LiQqwMTRQMAMoF4u+si2kL1ekh0VR0VtVNYhsQQaeEihiGbGQd6CPb+OvMleL7L5tkbH1htCw0JUnNUQsSxwE+AbGD8Gq6egXtsuEN3Om/hO5JoFa8JtW06QPMr4ybCs5NeXdiSZSpLJZPADL3JzrRzFoINUPIMfCH5xiFTc0Ou6mFyIu/xPpDNl5L0Ay81gp2uw3ci8+YEQGJtY3MGyJcoMK2QLBYK4i5jIYSGegGQCAkW7diHpMhg/MiJsy5Lo86IPTQ1QXQYt7TA4gGbikYY3Ein6MIRCHxprxDpgHGzcouFgK+LqGvX3eqWx2Gliz1L3oe0Bdw6plJ+gUj5LnapZiozWGxfep/39gxoGoaqqel6g13zvTu3t7dd7H1ykP73/Ce3t7dP7H3paoVyv/f4d2t3bp9/7wZ3a3dOnQRBqe3uHdnR261O/fkFf+v1yVVXt7OrRPR3d2rF9l46+6FplT4/adz2pYtep/PAhpbtX5eQLldmfUFm1VaWoSn+o8uALSnqKyqU3Ka0DiqrKln6Vu59S6fCVjV3Kpi4lb1Quvk6FYcrkBZp8U7Xqwv8XQIPaydhp72WFy70/aVdbnhUrk9ZpZ6ppOFik+fko/68eM6ZNory8jB/d9QBtLW0Y41NeVUVlZTndXR0cfeRsKisrOG/+KXznuwcxcdxIqisraG5u5vHHniBVVsknPzEP13V5fcWbJFyX9es3cuq8ExkxfBjLVqyizXax6qvQd9+FsBMOORgSlZBJwG13o/VVyJ0PIXOPRs85Htn0BfT8zyJDAVx0DcycgaxdCxVpOP546OyHR34NK9eAFYdD5pBIooXX3rAhmw/F+RN4JRCiAFS+Yk27wtgrNeCs51XiByvpKeqmx+mWLdtVVfXa6xbqxZd8TcdPnKm33nGvGmP0ym/coLt2t+re68GHn9Q/vrZCwzDUxtEzFNDbfnSfqqre+/NHFateAf3oCZ/UXC6vW3bs1saa0coND6ndY1R+vUrlrmeUjTmV5e0qdzyh5FTlyttVQOXz31YGApW7F6u8lVU2BypX3KJSe6CCqBx8rEqnUfnJsyo4SuIAlbLjlR93acNvOgKJHWmwEq/slxQuSYGTvFhic9R5rNWXn+TUqv6YYo/TERMO0/6hvBaDUAt+dATmn/8lfWbxEg2M6sWXf1v9INDlK9bq5m27NQhC9YJQt+1sVajSq6+7XVVVn3rmRYUahTKdPfdULRY9bd3TpeMnH6EQV/uRVcpaVVlRUFlllHdU5fF1Kvf+UWWrUTn0VAVULr1NaVWVM76scvg8lRd2K9tU5akdKql6ldMXKNtV5bIfq9hNKpkZytTvaGq1atWFj/owQq14/OK9gK/94G75J9XbPmSe/p3NrKTKlI9DWGT4yDHE4y4v/OFNGuonUVV/IM/8+ndMPHgaG3Z2oJaNDTy2aDE/uPluxLbwUV5b8TannHE6377qUt7ZvIvv3XArY8aMYuKU6dx7/48oGvjO9bfjZ3tpnDSLMKxFdhXhtDlw0fwok7NuG7T2od3AuBnIAUehs8+GNwuQK6B5hUvOgWUdaHo0ZBoh0Qi7QtiyE9U4UAUnnUUZgWYXP2dj9Q2ZYvHJEgPMXgbYdNKO3f+EPvs7cQazIaeeBdLEpEMOxjg2azbvpr+3hb7OdhpHjKByVC0bWzqpHzkSsW1aOrp5+IH7WdeexbZtenIeV9/4fXwRqseM4pXXFvPCG3/kB7ffzAHjR5CPu1x903fZuXMdH//ixVAcgbO7AM3roXoc+A5s2Q2/fRBpFfTUq9Hv/h6Sjcj918OEo+GGZ9CvvAROPbL0NejegTbNhRYb2rvATqEj5hA/bTL629dDr/kNESd4AmjfC7B0/qzWlNBbtffNT1sPP2Nx6acIZ32Ot998kQu/cRNvvvoallsOWAwMZfna17/HlnVbwPfY3d7Ca0uXUSzk+OIFF3PQ1Em8vWINf1i6jIryDKKKG3fo7uxhKDvEc0teghAs28bF8Pxra6CmHdPXjDoJpH0b8rNbYdXv0Q2vIN8/D5l8bGSWNyxBVz2LjJmBNG+HypHQsQGW/RKVJLL6t7D1LehoReJN6LxzqUwH9N37CwurxaiGt34wYixW8ZhVfpqmnuvxudtTMvMU6hRrhEpilIrToFClIApphYxCQrEaVOIjo9ekFapLr5Olu5Tu8dKzeOl9WWk+J7rHR5Z+H1eoUXGHl76TKH0npdjDSt9xNfKAEpFyjY1U7OFKfLJK+RzlsJ9qao1q7YLnfJis4iQfe39VXN5XJlMymYkMVr4dP/5KR2691CouXCvOExcQSh6T60VOPAEZHMCOx6JytgjiuARLnodMJdb4Cci6tZhkCvvoY6CvF7UcJBFDfQ+GNcHSpTD5AOjshjUrMJUNaGMTuvGdCPxw8r9DVyek01GYHAZRea2+Fjo7UUuiHEI+h0yYgL6zHi0WkdHj0ZfeiGISdyL84CaGNea1/fSLjOaeDzTITwVv8z7M4/vwAQrYeF6XJO1EsHnPUelRU8PwzA9Z/uoE7Po9xFKIY0MQYBJxKBbRvgFMSzM6MACxOFRUYtr3oCLQ0IjZsRMtFtHKiugehmgQoG4M09ODaWtBE2mkrAz2tEEyjYwdCz2d0NEF/b0gFhIGUUUpV0rZEeXORWzI5ZBEGjQFe/oRqUHnf52GM4Yx9KW7w+LWJxyR/htR7/H9wNV/FSS1FwHuEqtbaWdOPqjq0YVhz0CNbb5xNbLjV1GsEgxFdfq99XvLIoozTeSXx1NRKO15YJcAGaEfJTo0hFgCvAIQII0j0YEhyA1BMhXNUcxF35VSTWlvjKBhJCEKqgEiTvSZmwS3DGJViFWOHnMFlTcfR2zhi2HHj75ui/vuOvWGZgH++5Hl9t9AjvnE3T9ptv2z4Vu+lH/uMMmPnCuyejuS24YkMohjIZaN2DZiR4vFsiEefy+9FXOjhIrjQCyBOA4SS4DxkUwaa+GtyMknwqt/KIEgSsmReAJcN0KMOi64DsRikYQ5bjRvLAlODGLpqBKcqEZMAv3Q+aRunEfFi+9o2/euVbHfCdXL/zuY3SXa9P3I7/dfkVnM9b9lpbikuO5X91hX1PsV93zR7c//ALnVwJ4XUSeFUIjy8YcdijQ1gue/d5iMlOCJpbsASYFlf0SGQuQr1yPTj8Bs3AoV1dDbgUyeDgcdCAU/Ks6oQFAqqRuJCrFGIePCls3opnchUQZOGvEddPq5JH54NrXrd9L8je8HIqtcDfIXgf/W34LJyX8Fi5dk9S3qjVxQ9rEFfuzmT7s9zxbhR99Bdj8FbixCb5oScFFNicW6r7ypfxWgqcihJ8Oll8FjD6CLHopCVtUPXtJeWL1YEdA6lkGsBBKmMIddQOqG06nbvpuWC77jB4PPuoTdCwmLHwiU/CCwtAIOQf45SQRjvQ0bZzibXT9z4Uy7cMBx6C4H2bMGFcBOUNJIEY5PSuGF/LnE7Xtmwqh+sOgRWL0MiaXYiwBEiCrEUpqndMeyI71gx0sps0pEXcRpwnz8K5R//wTq3tpM8xev84Oh510Jex8kLFy0H1T2f4QWj9IzQf4pSfhjiu+un8mKfFD5yUPEP/4ICfunIM1bEa83ytlZEfw9WrD1Xp6/RNA+Bll2dHTUIPHUfn0De5lgoWJHGt5yUMsFK444KSRWjjhpJIihw+agX/oWDV+aTOqR5br7a9eFpvCKK2HPAxoWzt+vi0T/Ebh85CMEuaclEZT7LZuO8J/fTdW08cY670NWseFk6ADpbolSWm4ygsbvRd9YNiJWCeBgIViolBSo2CUG2aUdtlFxIiC0VQJmWAlw0uBGhBPGITkWPe6zJK67gOHT03jf/GXY/uObRFhpi9+3UE3xor+3Z+C/3TBhxau+YLTsdnE+FKv85GcC95JT7IHQkcKT2+DFJ5Gdr0e1RNugolEhwPiIKSHJ1ezDfLzXBGi91zixt4fIKom7uKA2mBiaaIRpR2OdO4/aOWkSL2/Wru//PMy9+4wjbrOnXvYyCP5bDRP/s5YZJ/kRcTL3qNc4PT72eCou/GSo82bZg4NQWLIbXn4FNq9ABpsjkJJlIk+YEMUgqiXlWEqASkkqxCnhAS1QCzE26lSgdeNhxmyceXOompUmtaWHoTueCrufe9xG30G0b7UG2QuBf1nLzF82TUFS4hVXqUkvQMcnU1NPoOKcU0KOm2ZlY0h2Q0j4+jpY8zbs3gx97UhxAAkL+xixt1UmAsM4qLjgpNBkJdQ1wcQD4MNTSR02iop6iK/v0uwjS0z34qdtM/Am4nbk8fMLVf3r4X+naeov2+Zc9yCxMldpmD4bGW/Fx84mc/xRYey4mYQT66xiDCl0gbc7i9m9B1o7oa8PstmooGoRmdOKMqithqZaYmMaSIxwSKcg3u5rsHyjGVz8KgNvvGJrdi24XUZM4VEN8tcD/+ttc3+9cdJNzRQ7dpGGidMJ6ypJjSMxegqpaVPD5Iwpak8aLqaxSoJySzQOKohK5O9YClaIShbcnryG2/ao9/YWzb+1ToY2rrHDrg2gLWD394l6izQo3AX8nzZOvl8aZL9zN9yKp0816p6OiR1KmEkjNZBswCmvw6mswamoxk4nEddRQoMpeBIMDhH09xEMdGAG28HfA9IHdjYreK9LGC4ypvg00LIf4f+nrbP/FSMARtix5IeNWLPVyDSMPRa161C7LKp+SKnzJQRCH8sMIWGnSLgdzBrLhH8KQ28FETKRfybh/woGvA9+u7ed488uF6jFdWsctcvV1gSAhGEhEBnA97uBrlLU9vfO+Q9d/x9UgSZKvRlaeQAAAABJRU5ErkJggg==";if(!l.parentNode)document.head.appendChild(l)}catch(e){}})();
