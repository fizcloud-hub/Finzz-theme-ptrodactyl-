@php
  $nbf = storage_path('app/finzz/expiry');
  $nbExp = (is_file($nbf)) ? (int) trim(@file_get_contents($nbf)) : 0;
  $nbLeft = $nbExp > 0 ? (int) ceil(($nbExp - time()) / 86400) : null;
@endphp
@if($nbLeft !== null && $nbLeft <= 7)
<style>body{padding-top:34px}</style>
<div class="nb-expiry {{ $nbLeft <= 2 ? 'danger' : '' }}">
  {{ $nbLeft <= 0 ? 'Masa aktif panel berakhir hari ini' : 'Masa aktif panel tersisa ' . $nbLeft . ' hari' }}.
  Perpanjang di <a href="https://t.me/csfizcloud" target="_blank" rel="noopener">t.me/csfizcloud</a>
</div>
@endif
