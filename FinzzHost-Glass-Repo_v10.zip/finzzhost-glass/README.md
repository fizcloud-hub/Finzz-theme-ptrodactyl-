# FinzzHost Glass

Tema Blueprint untuk panel Pterodactyl yang dipakai di layanan hosting FinzzHost. Mengubah tampilan dashboard client dan panel admin, menerjemahkan antarmuka ke Bahasa Indonesia, dan menampilkan info masa aktif panel untuk model jual panel bulanan.

## Isi

- Mode gelap dan terang. Awalnya mengikuti pengaturan perangkat, pilihan pengguna disimpan di browser.
- Efek kaca (`backdrop-filter`) hanya di dua tempat: kartu login dan jendela modal. Sisanya solid dan datar, supaya tetap nyaman dibaca lama.
- Terjemahan Indonesia otomatis, 235 entri kamus. Nama file dan isi konsol tidak disentuh.
- Pesan server disuspend diganti dengan arahan ke Telegram @csfizcloud.
- Musik latar dari file milikmu sendiri, dengan tombol mati/hidup di kiri bawah.
- Tombol Bantuan ke Telegram di kanan bawah, badge reCAPTCHA dikunci selebar logonya.
- Banner masa aktif muncul di atas halaman saat sisa 7 hari atau kurang.
- Halaman status di menu extension admin: masa aktif, status akses panel, proteksi admin ID 1, dan ada tidaknya file musik.

## Syarat

- Pterodactyl 1.x dengan Blueprint terpasang. `target` di `conf.yml` diisi `beta-2026-08`; sesuaikan dengan hasil `blueprint -version` kalau beda.
- Akses root SSH ke server panel.
- Untuk musik: file mp3 yang kamu punya hak pakainya.

## Pasang tema

```
cd /var/www/pterodactyl
wget -O finzzglass.blueprint https://github.com/GANTI_USERNAME/finzzhost-glass/releases/latest/download/finzzglass.blueprint
blueprint -install finzzglass
php artisan optimize:clear
```

Ganti `GANTI_USERNAME` dengan nama akun GitHub tempat repo ini berada. Boleh juga mengunduh file dari halaman Releases lalu mengunggahnya lewat SFTP.

Kalau ada tema Blueprint lain yang masih terpasang, hapus dulu dengan `blueprint -remove <identifier>`. Dua tema yang sama-sama mengubah CSS akan saling menimpa dan hasilnya berantakan. Untuk update tema ini: `blueprint -remove finzzglass`, lalu pasang file yang baru.

## Proteksi admin dan masa aktif (opsional)

`scripts/finzz_setup.sh` dijalankan sebagai root di server panel.

**Proteksi.** Skrip menambahkan satu baris ke `app/Http/Middleware/AdminAuthenticate.php` (cadangan asli disimpan sebagai `.finzzbak`). Setelah itu admin selain ID 1 tidak bisa membuka Settings, Application API, Nodes, Locations, Databases, Mounts, Nests, dan Roles. Mereka juga tidak bisa melihat, mengubah, atau menghapus akun ID 1, dan tidak bisa menjadikan user lain admin. Setelah update panel, jalankan skrip lagi karena file itu bisa tertimpa.

**Masa aktif.** Skrip memasang perintah `finzzpanel` dan cron yang berjalan tiap 5 menit:

```
finzzpanel set 30      # masa aktif 30 hari dari sekarang
finzzpanel extend 30   # tambah 30 hari
finzzpanel status      # sisa hari dan kode bypass owner
finzzpanel off         # tanpa batas waktu
```

Saat masa aktif habis, panel dikunci dengan mode maintenance Laravel dan menampilkan halaman "Panel Disuspend" berisi tombol ke Telegram. Pemilik tetap bisa masuk lewat `https://domain-panel/KODE` (kode ada di `finzzpanel status`). Karena memakai mode maintenance, permintaan dari Wings ke panel juga bisa ditolak selama dikunci. Server yang sedang berjalan tidak dimatikan paksa.

Masa aktif sengaja hanya bisa diatur lewat SSH, bukan dari panel admin, supaya pembeli panel tidak bisa memperpanjang sendiri.

Copot dengan `bash finzz_setup.sh uninstall`.

## Musik latar

Taruh file mp3 di `public/finzz/music.mp3` pada folder panel, pemiliknya `www-data`. `scripts/finzz_music.sh` mengunduhnya dari alamat yang tertulis di variabel `PAGE` di dalam skrip; ubah ke alamat milikmu, atau unggah file manual lewat SFTP.

Browser menahan suara sampai pengguna menyentuh layar. Jadi lagu mulai pada sentuhan pertama, bukan saat halaman terbuka. Kalau file tidak ditemukan, tombol musik menjadi redup.

## Menyesuaikan

- **Warna:** variabel `--sf-*` di bagian atas `extension/dashboard.css` dan `extension/admin.css`. Nilai gelap ditulis dua kali (mengikuti perangkat dan pilihan manual), jadi ubah keduanya.
- **Logo:** `bash scripts/logo-datauri.sh logo.png`, lalu tempel hasilnya ke `--sf-logo` (baris terakhir tiap file CSS) dan ke favicon (baris terakhir `src/lang-theme.js`).
- **Terjemahan:** objek `D` di `src/lang-theme.js`. Kunci memakai huruf kecil dan harus cocok persis dengan teks di panel.
- **Kontak Telegram:** cari `csfizcloud` di seluruh repo.
- **Build:** `bash build.sh` menghasilkan `dist/finzzglass.blueprint`. Folder `src/` dipakai untuk merakit file wrapper, jadi file itu tidak ada di `extension/`.
- **Rilis:** beri tag `v10.0.0` lalu push; GitHub Actions membangun dan melampirkan file ke Release.

## Batasan

- CSS menargetkan nama class bawaan panel. Setelah panel diperbarui, sebagian aturan bisa bergeser; periksa elemennya lewat inspect browser lalu sesuaikan selector.
- Kalimat yang tidak ada di kamus terjemahan tetap berbahasa Inggris.
- Belum diuji di panel langsung lintas versi. Yang sudah diperiksa: kontras warna WCAG AA di mode terang dan gelap, serta logika JavaScript dengan DOM tiruan.
- Halaman "Panel Disuspend" dari `finzz_setup.sh` memakai gaya sendiri yang lebih lama dibanding tema.
- Efek kaca butuh browser yang mendukung `backdrop-filter`.

## Lisensi

MIT, kecuali logo FinzzHost yang tetap milik FinzzHost. Ganti logonya kalau repo ini di-fork untuk merek lain. Lihat `LICENSE`.
