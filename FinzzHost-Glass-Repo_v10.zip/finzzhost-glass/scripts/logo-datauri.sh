#!/bin/bash
# Ubah gambar jadi data URI untuk variabel --sf-logo di CSS dan favicon di src/lang-theme.js.
# Pakai: bash scripts/logo-datauri.sh logo.png
[ -f "$1" ] || { echo "Pakai: bash logo-datauri.sh gambar.png"; exit 1; }
printf 'data:%s;base64,%s\n' "$(file -b --mime-type "$1")" "$(base64 -w0 "$1")"
