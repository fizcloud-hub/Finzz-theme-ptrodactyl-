#!/bin/bash
# FinzzHost Protect + Panel License - by FinzzHost 2026
# Pakai:  bash finzz_setup.sh            (pasang)
#         bash finzz_setup.sh uninstall  (copot)
set -e
PANEL_DIR="${PANEL_DIR:-/var/www/pterodactyl}"
WEBUSER="${WEBUSER:-www-data}"
MW="$PANEL_DIR/app/Http/Middleware"
ADMINAUTH="$MW/AdminAuthenticate.php"
VIEW="$PANEL_DIR/resources/views/errors/finzz-expired.blade.php"
STATE="$PANEL_DIR/storage/app/finzz"
CLI="/usr/local/bin/finzzpanel"

art(){ (cd "$PANEL_DIR" && runuser -u "$WEBUSER" -- php artisan "$@"); }

[ "$(id -u)" -eq 0 ] || { echo "Jalankan sebagai root."; exit 1; }
[ -f "$ADMINAUTH" ] || { echo "Folder panel tidak ditemukan di $PANEL_DIR"; exit 1; }

if [ "$1" = "uninstall" ]; then
  [ -f "$CLI" ] && "$CLI" unlock || true
  [ -f "$ADMINAUTH.finzzbak" ] && cp "$ADMINAUTH.finzzbak" "$ADMINAUTH" && rm -f "$ADMINAUTH.finzzbak"
  rm -f "$MW/FinzzProtect.php" "$VIEW" "$CLI" /etc/cron.d/finzzpanel
  art optimize:clear >/dev/null 2>&1 || true
  echo "Protect & lisensi dicopot. Folder $STATE dibiarkan (hapus manual kalau perlu)."
  exit 0
fi

echo "[1/5] Memasang proteksi admin (kunci Settings dkk untuk admin ID 1)..."
cat > "$MW/FinzzProtect.php" <<'PHP'
<?php

namespace Pterodactyl\Http\Middleware;

use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class FinzzProtect
{
    private const LOCKED = [
        'admin/settings', 'admin/api', 'admin/nodes', 'admin/locations',
        'admin/databases', 'admin/mounts', 'admin/nests', 'admin/roles',
    ];

    public static function check(Request $request): void
    {
        $user = $request->user();
        if (!$user || (int) $user->id === 1) {
            return;
        }

        $path = trim($request->path(), '/');
        $deny = fn () => throw new AccessDeniedHttpException('Fitur ini dikunci. Hanya admin utama (ID 1) yang bisa mengakses.');

        foreach (self::LOCKED as $p) {
            if ($path === $p || str_starts_with($path, $p . '/')) {
                $deny();
            }
        }

        // Akun admin utama (ID 1) tidak boleh dilihat/diubah/dihapus admin lain
        if (preg_match('#^admin/users/(?:view/)?(\d+)(?:/|$)#', $path, $m) && (int) $m[1] === 1) {
            $deny();
        }

        // Hanya ID 1 yang boleh memberi hak admin ke user lain
        if (in_array($request->method(), ['POST', 'PATCH', 'PUT'], true)
            && str_starts_with($path, 'admin/users')
            && filter_var($request->input('root_admin'), FILTER_VALIDATE_BOOLEAN)) {
            $deny();
        }
    }
}
PHP
if ! grep -q "FinzzProtect" "$ADMINAUTH"; then
  [ -f "$ADMINAUTH.finzzbak" ] || cp "$ADMINAUTH" "$ADMINAUTH.finzzbak"
  if [ "$(grep -c 'return \$next(\$request);' "$ADMINAUTH")" = "1" ]; then
    sed -i 's|return \$next(\$request);|\\Pterodactyl\\Http\\Middleware\\FinzzProtect::check($request);\n        return $next($request);|' "$ADMINAUTH"
  else
    echo "Pola AdminAuthenticate.php beda dari biasanya. Proteksi TIDAK dipasang (file asli aman)."; exit 1
  fi
fi
php -l "$ADMINAUTH" >/dev/null || { cp "$ADMINAUTH.finzzbak" "$ADMINAUTH"; echo "Patch gagal, file dikembalikan."; exit 1; }
chown "$WEBUSER:$WEBUSER" "$MW/FinzzProtect.php" "$ADMINAUTH"

echo "[2/5] Membuat halaman 'masa aktif habis'..."
mkdir -p "$(dirname "$VIEW")"
cat > "$VIEW" <<'HTML'
<!DOCTYPE html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Panel Disuspend</title>
<style>
:root{--bg:#e4ecf7;--text:#12284a;--mut:#5a6d8f;--acc:#1479e6;--acc2:#2fb4ff;--on:#fff;--d:#b9c8de;--l:#fff}
@media (prefers-color-scheme:dark){:root{--bg:#0b1228;--text:#e8f0ff;--mut:#8ea0c6;--acc:#29b6ff;--acc2:#66d6ff;--on:#04142e;--d:#050917;--l:#1a2850}}
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;background:var(--bg);color:var(--text);font-family:Sora,system-ui,sans-serif}
.c{max-width:430px;width:100%;background:var(--bg);border-radius:28px;padding:30px 24px;text-align:center;box-shadow:8px 8px 18px var(--d),-6px -6px 16px var(--l)}
.lg{display:block;width:120px;height:120px;margin:0 auto 4px}.s{color:var(--acc);font-weight:700;margin:14px 0 8px;font-size:1.05rem}
p{color:var(--mut);line-height:1.6;margin:0 0 20px;font-size:.92rem}
a{display:block;padding:14px;border-radius:16px;background:linear-gradient(145deg,var(--acc2),var(--acc));color:var(--on);font-weight:700;text-decoration:none;box-shadow:5px 5px 10px var(--d),-4px -4px 9px var(--l)}
a:active{box-shadow:inset 4px 4px 9px var(--d),inset -4px -4px 9px var(--l)}
.f{margin-top:18px;font-size:.7rem;color:var(--mut)}
</style></head><body>
<div class="c"><img class="lg" alt="FinzzHost" src="data:image/webp;base64,UklGRtgoAABXRUJQVlA4WAoAAAAQAAAAnwAAnwAAQUxQSM4GAAABDsvWtqmNJFlht5sxj7OanQW7HmaeuQCe3DXzBYy7Tq2aubPvANfDzMzQNMzMzAVGneOQZVmK+NffH3/Er4hw4Ehu27CY1OlIp7q/AA5oZro91cRrXkvhpQjDd2VJKljRdPrWBZfsJHAbup0VFa+posW33995w3V3PfGJp372p38dHU8jB0irn3jiruvekPrFD6xnvEQyAHxo94GP/+JEXlnb8PG4e6jwAtV4iAwvf+R748L7n09jnCkWJQrVGCPE6vh7j1w+9ArgJACed+SLR/OlzqLOF9UXDI0qSw1fbFMHMN3Mg6wH4MDo6/PCXDl3E2phCml0oAP0MtcZwElveb+tn84WUqOyRlue3oIOupnb2fboB0ukQt+a2opIGm3bxN0+w/v/kst8XX295RD5Sxg62iYBF+392/KlUbX0wGn5NpzbkmU469a/L7OFNK68TP5+a4vMuFZ19S9WMzeSkJwqMsALP7WauZO0AXAFVPTvOJHP5uKUQqW9I3R6TqCClz6Zy0ycUxWJWL4rFzYXh8drqpwqGh8GUuO0fR8SmYujCpGgDbMUr/1VCeoomLRJywxunuRRnNYok5vR2JG9MPaWu2txXMGy19Q+QtB/ZynNadY7A5qwLs7+XBnNdZYyUgM++FY+yT3RSR4GtVvC9reLuS/pt7drNoNBwb2yAUytzk9a98ue5Botk/7nrftmCIbrO8p8l3X/LEFrMsXeuhX5sx6G1uQ3FXMfU67FunhVnC38FNb4KqQadvaD3+Zz8VQhYcBm8w4fzWfiraq0GzdQ3LJK8pUToBuSXjhZJfnKmYSNOFnqf7uI+QzFkHgT7I4i5jekG0AGzxkXMb+h8XNgqs9/oYj5DjFSZb/cOgV2eUXLzBm/XcwpEHCIJqsWb12t8b+EKwWT7fv3fEGDMIJmpkp82EYqQkCqEC/834KpEOb2wvWhhwdspCM8AF3Xhbf+YSMdIbUZr4vvsJGS0K4L3P/pYk6JgFPI1nR5o8yEFFVpy5sYfGgRaZHIAabULz3OTIswayizHkZFNi1klJEz/padoWYiMJeML9MCRgykWB32cMSO6Rm20NXFl+2YnuGXYVb84mM5RQOJWrQeLreRonB5cah4xM5QNPFIUbL0g3xOkUBSlwszByZ2hqKJyQE7kbBrZ2ia2EWqdMROztG7wSfoWsQlkqH/S8ukiRhDhw2GJyyTJmI7hEl4vY1UBe6kHq6zTKqIAaq4izJhK09QJgGair3oapUyPEUZRTuM9DPKpE0dnP6nfEGVsPwpAFv/okzQdnDBUcokXABcMqZMxuhgZ0qZxESf0Degj0JfIwL3C/TtV+k7LqHvuI6642IKzyvoOy+j77yWvusC9F1XIe+6FH3X9ei7LkrfdWXyrsvTd1+DvvtC9N1XI+6+JIX3dem7L07ecwX0PZdB33Mt5D0XRN9zVdQ9l0btc3289Q9KyMypzcoX5By9R3lgXQQMX/g/OgJze2FWrC5v8jAdIUpAAtaHff+eExEYQW2sEG6lIkThKhHIzBm/pWHbCw7RZFUEiYrzC5XLbaxoX6DAVLiyw+A5Y/W+hHX8HBhU1R7u8L8kiqKHypKl/rd9h1RiSIzqmvDCid8Q6yQU5zeAbvEbihKK2AaQ4qM+QyoteozN1PDgt/5epYKEAa903IjzqugrhzW+apW0IecmXzlRGArUYnsy8VEmOdfkyBTv8jGNkqCMmsz0P++fRUEwdTkgOPtJ3yzKkwwD1GiDb/tlUb49qNWBLraX5pVvIwE12+Bb/qxnkoeB9dqNP+dLGkW5AQcM+u/Mowd7MI7yzmArmrAMe7n7Z2pg2etkzTjAgpsnrrOiTG6GYTSmPbz2V06zOErSws60Sdv3IRFnWRAJ2rADXeDweAk6io4PAwlNqxG89MncxWN5FYmw78oB7aF/x4l85lgRVNo7wiqteRB44adyp4o4irQBMHBFMwWu/oVN3MlCAjSDQ2oYZ936d5u4kf391rbavqD5DchFe/9eJg2vDssscFqzuXCqaHj/X+x/qjE6K0T+EoYrVS4mCdge/SC39AYAtnxJo+0lo5C5m5z0lvcftUC95awWCektWJs52gYHRl+3LWc1tWVEFRGk0YFOeR+XCQbA8458MeSFKd2EytDCnIQvtqkDmCXDD5XCpz+8/JHvjVe2BjHOFIsShWqMK1uY8fceuXxY+MYNCuoVwId2H/j4L05UX7Th43H3EJcjngEJVvs7b7juric+8dTP/vSvo+Np5ABp9RNP3HXdG1K/uMleIr5qJqXvOZ2+dcElOwnchm7pZ1d2VO41VXXdX46TqiNcAFZQOCDkIQAAEGYAnQEqoACgAD45FolDIiEhGWwW0CADhLYAaGUILT8jfyf9V/YD2Iqh/SP7L+hP7r+1vyA6HerfJ85k/1H9//eX/KfL3/Kf6T2Kfl7/oe4F+oX+Y/vf5L/F36uf3K9SP8//vX/T/zHvR/6P/gf1X3m/4D/UewL/VP75/0PXU9iX9wPYF/Y7/3euP/8f9n8G39b/1v/p/1/7////7Ff6L/f/+T+f/yAf+71AOFw/xnof8f/yHhT+N/Qv4D8qv3n99PNv1s6k3zD7c/pP7r+4v5efMP+9/Krzn+S/9p6gv5D/Mf8R/Zv2p/OPl4Nk8w73d+kf63+6fuf/mPj3+I/5Xox9iP957gH6of7H80vW1/2ni3+U+wF/PP7V/w/8d+W/xrf8/+O/2v7g+2v5//7/+c+Az+Zf13/gf3n97P3/+sH/6+4z9xf/r7sP7Q//92u5bmv4YvFLO78//9iCyNfR7v8td5mFggvKyIhA7kvcjgRSgVOaeUpveTl57U7flZvH5956mELjC85FAba04Dug+5mNeZTA6AoKcdo9Eoe9VWa5rIimbwXGJ1w4+ERgIK42CGfuRGYZvNC6pd3Zn7Mm8uIsO+Huu646zTLREH+oieTQ2xHTciAvVUiQjGIBN/En1xk/czjr33FebCto1YKgVuCAz37Vf3m9r8cBIcqzeFUwO39l4YA3kNJ/4quWdP8p5IblV7y35LrMPkotOUKRx5rSRSawL4v5EX7ZvvqUXrWiaNLpk72pBxXeR/7Gi3oZN67YgbbxyldUUYzVVGVBbqHkmUMH9T0iZa2Xr4Ai0vL1gWAeo5tku3BiBle/lrdadadA+RjqGGowstxAyH7IhKRfHecbIJKo/VSXSJZ4vRc0rw16Z6ZpGW84K3VuDadlVZvCvZWQYyIs75MlPSB2ekP93UE2q7lXoEjlT/hE3iYEA/FRrs3VQeTVcCnShDdK3RfbbG7vaeu4nUTr3YLCgjiNqAIXNdjhiekzWTPAux7BIEIavHFQhMAXGgnaMk0qDzfiivwgm/UuSO+Ei++qp7dc34ijaCmtCOl/R77443Yo6sA9WWp4Yc8BBjHozYOWe1p0o26m5EgAAP7/YBg9AN9YzU1PY7Gi9CGkfm+JUTv+WPSeTk0hO7nPGn4Z2JFtDknuK+m5O7Ykp7ubD5JeWjBIJD02tq6qcuP4EPVHe7p/O8FwsZdlrVf2sVDW+XguWk+wmw1YTdvwIqvTer3+Hv0klWqhIB9vKT20OsIse/Y/ROC0qUikxd/+MkVoEQOsN8U8zCDH35QvvH2QKc8XHxd+nu+7TrOD2bwKO0d1ePi1Pr8GjkPb4UFeyKuKhySxffT8owoThEXvjp83GWksXUUApj8JHeVdOh40Zufspq67M4eAf3tx5zLHltd+MTLNrthydxWG0M4m/A/KtHm4Bi/uWGSPMyhMiZRmG0AwkeWXEDNDUojSaAKlyfCfwmsXyDS0ZjIU5cS1h98ZK4OQqrXFHwyCv+q1pHit43/lYVV7SPK0acdHnQfOrT/BDr1/V3U1gNfxv3syX6cEEyphBk+xxIYbIGv8+4hl8kMVQCWLcPP4Tdzha+5lhgr1f3LYIg7WavcyRM/lG3xHs6M7d9nDHoolPvFcMdzc2MJdj2Zn7iOs4bvcrHNEtfq8OWe3o3jueqPaaSEaB9YAZ+UjJfyf52E4f347zhbR+87khVvINnA+zWdIQg4BteKgXcJkvDfP8HJfHABQBy/LnnW7RIuAuMaKlhAfKuXRenDUREHzajmPVtuX6y+/waEEQcZoTdtSkp1WojzSyZ6AmUeYXrB0lI9+Jk7muMg+hYd8PfNmT4ss//D5X/BpE6bnuffzSegl+2cA8SnJ3e9P2cAfnfP5c65CmDu9bA7X8ArfCgmbexeZsFZidqdx8UQuedxuFrkS7CF0gJFaMh7IdiysAtF/YPK6owq0Y/KmP7r5VcNazFXozy6gNr9V9I86liA/XPz1jY7OHKBETwuvNkNq0EGWUOMaCnu4EPJ7TCtc9CXFBBY/Qzg7Z7Ecr2P8jjX5EgWdggbQ+5rgPV8tijtbJmNz/f55rPBW3uSHKo8+uajUMTCDZ+Ep/RSq0TCWU1DTjgFrI8uE5g1oQhk1gNYTOQ3NEauQ30MEj6qHErz1RgdY/QaSTc3M7kEtmg8vpBb4JLicQUjuXob7PE660c0Je3QOwTOXWrJZ6bfRFrSvC7nuD9s22CL5Qz0xKSmUIYaFJ+XoYbhB59AjOdIVZDO062gFCtL1W0PCXZXqn2AhLw9HIPMUNlpJT284oghZdkc0L3CnGi0diQKNUVkG7tc40RqfS9ArJON7SjYfsO/eBGy765aqtNZJzCWTxGrkwUCvwNeMhxsSYsG+ogFFokvh7eBi4Yxu6Rkarf3WcnwSMEiSuQrPZF83iDBAZ/wpf2WwaeCHWrxys9g/ah/XLb8dAcYqZAs9h9AyEOGiAC82tuhzSJzbgbBagAYQv6n+R94ITBIbre+uKJ2zOBWD5hbFzcVfKisauhoyNiR4fA1FKi5MN/lY0IIPmFqD9TWpz8eFTPiI4ZBJqkMs/U5o6JR9aJXAiB4u8VL3idj0yKFAAhfBRXVeKDEm5n61ybcWOJmsn/EFMlgc5lixt4/U1GMdlFVBADn6qoJy4FxZngZ1EVV9YYAwp/TuVwxOBP9srGPbLW5zpb3NsbVO+LSxmeiE3M5+Z7HXIa3gvI1JQR4MUg+CvS6SFvQ1F4mLNVTuBiXxxs7Cw8o3S9NbgMpyfVQD2I/dRMzKjz9IP87wqBcggKVbc7cxQKjprbYW6edYEsX+JHpUNNakDEBHIjpOjY/+IYKit7cQ4LuhXnpaI5nh/fKDMRL9PbRvtTx9VMg016Q1x3a/W9lKKE2DQ5TnYX/UVzL5Yu3uUtpkPZzyORRjFueBSgRI70cAeBewLwESiU+zkm22kPVfGh/C5rJH6f314zsj32EzE0duwVbnzKtdHz1uE2lOynSLmxMVf9Qo9OvKJewhQu3Glm6hbhLFdoV4h4bLy5fNfeoipQblq/ILO+n4XpV6F6V7EfhR+wOPadrkwD/Lbz2Fz01otiLqXHQE6zZlEN5qqvRRc9EoB0wZhpszQpy3QeI59nEPVBjsi2FjvWIRfHMFX52WhYAgJe1TcIxGcKyUFb8GcNeZx0QeouxbV0wz9nRsOCL+bwTEbGhBJbWpQe1RjP7WLmwZWxPkkdOe5w4Gr/riSDGHYeV/lYwWLbpwjxZ4+CIz9peEW49ijE9n3smHdL6vp8aRZKmD3Aco1EuQ4FE8Oss00tG+ePcHtfpW5zxOfzuGgyYWC5K7ipsXEkG7qwFnUhPyVbZ6QSXj89dkkNf+p2W60vN65uk9Abe1L2lMsL4x3XSmFHltMjJ7mHt34JMc2NYtFrwTwyW3IGmqIOQ2A3Abw6woKmsr8LAKCsq4yH+v5PbiqIpbE8zq/NTZJXxWCgwFwVkK4NBm2Sod51XLmAaxDuiy4wtBeGignq1eBuVN2ycynrHo7784SQqHX2I4TY6J7h5eORE1zJxmLTL8lj09JE+YcedqaKFRo8x/xAz7Q14059XAUfRvAJ+6YuGWvn/cNYPjldn1BjLt4bAZID791jkbCtuLYHrBD8bXOuJnl7mFgxpYs6AqfbMSlL4pgIp0RSMGzbNLxh1mp4oCVQrF/l6YROHXbtJAGdnV/PFcP44JCq3NrhQNMaIehWZQG8CLep6aUDWIRW5t4tDrvXIpADc2E1H5bAgQXdZmbf96fSrPPPbM0u3cE17PYAk+DqhK12JAdjP6oy/dcjhQo6aHhQRxuEDtHQGjhqN+/a6GAywIZ78N2X8RhHBHJa2R27YOxZppcAEmTtkEUR510v0QPeleJH4qM1vySyy+dR1KYn0KWAGZzeXcBQgUGNStNXil7IcsUfQSzRbBNiWucwORHLGPfHiKQ3ulq8xzqmRtgTtPf1azyjis92ZWBUNKw/XkSKK72Dlu+wra65Bmk28ic0kuaNPd85HsWzCEeO/CPV1FAsyF4KRBugLqtn7UMiynOst9lPCEmYJiwr6U79qvWliEfNevqIB7/JbFeJDU0PpUWTTQWXcYkzjL7a3DFuQjZLMRCO6+82j+zJDBJcDUY/aija/IYSWCYqOGs/N1dQDz0D5Sx+MiZhteaIACm33fkdYcyFmbi/bLt9mHIlkRzUs8XmSVSmoi/YQ4fPtxu8BVZHOyxSesO8FdZwl/ryGA4AJogzzNYeiiD8JdvK8IUYx5LwRba8eU5KNYrFrImX6i5O+0aBkN9voLBabeFPmIxTP+HR4jrfn+j/QwP7e81TU85hW5cd6NX8/IM2s5+AiEnxWUnWDGNGw/hdwDWyijjYoV3RPP37Y/KOena+WHAL8Myr7GKfgDjc3bv5OyVPAB4r5GhBq2hri5x8TG74YwaNjr4gQhL3rEwV4zMFEIGPdDsXJoeEFNaWCiTJdmijkYVpsrq3gW8y7A1gievCZSf6thCodcq7T7+YmmhMfSfE4ndQokSvJCaz4Ty69zQ+ZzIX9vNfc3uZXeAyZJ1UXbbMajIjIkarKrkQj1gYjLpA2YPaFe7OvdV2vvqTiwiRSLHy2uEqObZnaLddkJl1Xxa++ujsGVtL1CsvpBcLkspe/L02LA764B96fez9D4fMK5lvzZVupaQw4wA9LbcHdrE5vDePF+T2iXgs/bRx6XH1LTyOzL0Mowl9PyPwkGiYR/LXmDDP7yquP0BqWQYzm6l+ZKm3+fqdKk3NZIH1srxOpGjkPCcz3p/CT0Qnz3+6MFs2QfgZ320vq1WaMYyef78oMOQe/57saS8JqW4I1EVmWHJ/WcExzU97Yy4RbygUQVWWhRm77P8fGhTkrPEnoDvFABXPuC8sAZ93vUSQRAk8w8thDn3ne2swccjpbrKWXUAdLXdQjEMqU/ftUckNLNo4G9CDNc1DaoikcqkXjkysSjjjcIpCEQXVVCO5xEqHmxx0nKLuIqHXHVmVtcafBponYWst5lbuKkRJMYI66ThUIGArJqovuoAKlKEB/8fKLMC5BHhD85QfCoJ/J4k+GcAyjR16XHeD4ymdwou2EyNIxhbHgbrbimsSI9eOs0JrWVxwJnK92YHxlKlyUHtIU2sGzRbacz7tCfP4IkXLbjgqozr5mnbAwaLH/bImtbNVMaFeDi6oqjuD9owj9VW2upSUFZD67m+sk4MnJGFi6G0NzYHAFeoAmdgAO8ON2VBpabSvR2DGLo2j/1U224G/9kCaF/oyl8pyXJiecZ32QGJbKNM06Qo20NlFyrzFZqWATMDNdKvZfN+p2zbb26UgaiBY+0zizs654zPC8U2VNd6fK2baoxPUkCUM3RQbJGRPeGtF6gVQrjrxw/pMgyYeNMOxHC3pyIUdUPKxY9BDS8Drsiw/6AvbBiIuoFMbdRaq1KrPAsEhYPb7x9gcebz/5VA4d2iFPCRjo/B0c7V6ufcEz2VmfzBYy3pBeYjBCIuyDCDlL5r5a+Cz5enPfqd9Ca3a4ZH0pgRur+hKDRAfWk5/Gmv76dIWjOYZAcXRRaJXTtOTK5xY417JyPTGrX5OGqjNTXlJSAuCddOwyPGlvzclgIgsTUHAmIRpe1pQlR9Wmy+PtZq97VeWNdXSdUWKXP72mg0aYxbh0bAaC6VRB5o1FZtkVd2M09nTqeAQxtogkjIWJyUJl/mPRS/DhDssNwrh2hnembtZqEd5XLWHiGsXsC9RiBzkoa1iXorGqO+NNVt2sf4/WcDgImKztMzWKraIoikeirD2GpC28Kqw8HxnDQcuELojlefuwIuVW0FZcqvI2kcLiqu+Ofhk2TL+85dwpHWP6vIURGUq9/idG0uEUiK/pbR4TTVLAZXE15327gHfYqQO6frY4fLiGszWZ5KOETlouAXhGaAWabccrruT8rxupwjoGItF5WiRomBJD+wcfYTf6O4oqI4nLleZWAZ6Ebk/ZS+6qFTboPP7+FNQTSTi2ro0ZYOlROM4fRZ1fgWVCV1QVm9K/57xj1+um5kSqsde+vuhNCA4u47BOh/QLauS9cIc/DuZ+gyABXiq6UGHsGxKSTyWxwCrwu6OKg9vLo/GMLrF/r9YOCq+G9kFubju+3H26pAsC3gII81ZxqLHwKG7i/1ausx2ktQzjcw3uV0A9ugO08v8sJTFTUy5iEATR0ynS4G2v7LpQDK7CJ0qdCG2Y6lVQ+rJePHW2uoAmSI8GwxjQOad5BaVzxQZFc9vLCW0A89oDsp3KKYDuKFH6nRnOjCgF/83fqkUB7VhrqHF3qvhWOt4YlFeNGMHFUoMJrbMVorOrEUMQ9HVNuQt6Urm/SqeWf9OL3+T8cKQWfS+B11/zS3X2frUcCzAEqrQtK8z9J/SUCGqN+uGjJMWpcR+FHz9x3MkvPHaKDDp1tmwAGHDLfbNd13M21/M7jxJjTeX3TIq2h7u+ph/xWdDZXY4Pe2FkKA+9S1TGHttuzkbNDZcCz+NOLCE1yqKYcYIFKkPYCN/RDqFm9Z275UBiPz+N0wgq8X26RbVOabKuGW7AoOEZnYGHqTrZ5OlIKWeBgf51yVWNtMZmW6R7HcBL77hq99jzWPvK+UCJXwOri3dK62VhCVaLjhULg7/KmK1bRUhJ1mz1jf06Qmxq8J19njOXRA9w4d0GnG1xZa7jvLloU/sjvQIK/3+Jcvxi/0x7ZZpx9VxLi34tteKD2+YdszdyZ8jsPyuwMqdbU68tn18VtnF2A0qPlf3E5eNeNqxO1O8Lwd6NR0iqIcd6IprRAgYjkAhkOIeq0bR8AKRPU//W3cLrLpZPe+EHysdmGaEhXHylD4pU4aS8C+qxkF/ocwvMBjvzbY0A/NajvsHw5dR9FHZ8Qz4/G9zTvj4O4pIPNmuxH5sc8d5F5g8wewPLTw5hALdDwsbb0kWEM6WU4I4Vem6i8bueI/FeU0jcbrkOf0RtnV0r79artSr3jGlWWgyAwSBaxKdUpo/8pApeZshWGGbayVVc1GOd25x/XPM5flVD+tVRRVV8pfjFVb4z7L+j+7OimKXN0F9MJtIEqLdV9h7v2mp/nk4rXQG8r3aTPyx4tiwPIRFClAarWJXVAu2zAUksZ7d5p1pQgxajZDDmYJQVumSvSCiid7PU/z2hDVFlSdOIqPeRbzy/5ca426Oj21sfGOt4eiOKoSpCHyiMx9/zlQaYoFt5m1KjdxQ3QBsHI+tsK6mVNeSDNoAyfWMYlA+QsEN4SiR1/w3da+DFTaEV/zyQUHJmJxT5upa+cdrnpLnTHwv//PBwTWNJDGG6s73O5KTv4LbWAvmeyuP62/6ROwFUYVp58vsJu6TwvROecsmNIH16j8r0aLO+yIsXVYkxdO6w+GVNd1Nv8lBgCZumtPrW5qOqKRkWN8Tyuovx5JSXjnymt/TXOpsWV+HlyhaA7pd3M0GfP+OxuL4LsU+bjdQ7E5TuvUt6PtNy0X8lZXnVJsYXV9cdYvnRzZviAGfcTuPUH8Vcz6Wn6+4lS94aql+iE48CCutlMStdY+tqFjfQJRMzTVPEyqr9gaT/LDGUPYqzT9o4GLNXnTKe1rUPnDCjsx4VwJv/DTeEaMk7H+IJKt2rgy4CfSPHuGXM05h8iXvMjVL29rknbHolkf9cp597ZixPSGsm/0g1hTZlNP35oKle0bvNzbXyRQhYlKdRNq4Pvl+vuhiycC70yEN0mSJ+LlC0eZTkZYj5dK5T3I/cs1nvpD0zpsfbvgX5Mpc1g4tsJMsjGRRLXQGrNn4NRHuG9DkCcRcPfMTLMF2t8YpCm63pqi6nVOYrB9/waaCeGZLpHoC5pmXJL7GqkASSPjFKjWJo9qB9ryNOtAra3Ye6tfCxPx3w7u260WJ1hq4Zy34b7fMDAcn2C28RF0MZxNObgpd3XCvcxpd3sf4q0j+Lg2bbsB0zXL/YEM7O2DYKslza+jdl3wyCQ2HP980mO++4uiZ1Mq2qviXB6bMHWELaxJYPyhKvB13NMabprMEedLuYNQ0q6hUcFygpa75B4e1/InrrrDH83Q/JpqYs6V4sEvRstP/kGosebZozCbH4MFXQhhWdIZ7EhV/Nf0t6/e/rs9WgISVUo3KVMGgF+uqozPqNxux+3Mx7Uld1DnJE+7r//wfshqgnfBkN9Idkx/euqaXkIZgptsQf6uLI3C4ucEQjg7pD+6P/ylDSnhWXajKQrvJfBz3VciUIU8uoJ+NQeNDKcbmGeLuiAMd8kC6FK6OYBmOdQZqClLC5tCC5+Pq0v7Y/olBaLCAj4PwOHYPVXHqOm83VcJTK8kbxJgKeAn6iYQ6n9OowgqBW/fXBAlWOLlgwg5PTKkShRNTNYVuxRK44XyfbMNSRsGL6HS+ggUoBWt8xmTkJz9yPK4U9hqCrm7N3suZps681f/wPylmNFsqTPBvED6CY0t10GM9KFUlexBPPql2BLVGggZ5sIRiBcOMoP9o5cgu1juxsLJusjFO2pLeB2YLq5QxeJ3z4czJXhir7/76bivW16wFpfdkryz7oSd/2vSu/8epoT19hTlUV5tBNjPgHRX9KZDjh18VNcNM66BuYmSd9S9396ak8Mrum4p0RVNLG4daW3fTuFJ5cD4psOJPGNMPZ90GaAqyJ+mQkC5jGraPpghM8r6EGukQpOCvPzoy62Cq9qCb3g10u3QKdwRQgAnKDBVf74YGIqMfRTFj7d5heDFZDBJLpgc59t/j46iEsW3WHmF2v5o7tHChs16Lb972wv/QxLucH+aUnKxN+yyO4GDhY65EMyu6E/1xW7+1dm88S2DE6YPz4UKsKW+GEkMwI/wwpb+G2Hvvrfr5bslpgavgkba4QhmkVROHFpwpPaGJCrIG99d5MqaIp2SM3PPYCePDuoZzTiuPIU7uyKVoSxBGAgzbBs0CJx1pCG9E3ApSx7HIG+tLiyz5QGmony/zznRPYFxttuwRxJd08WE/ix/aFCyNwTfcZrKtCStw8OKJ6pYK10jB6wH+ruPOoTz9Erv/ArfMg8zfxr+r+7LWMwq8lv3lmjGHoOQioibqMsnyM3Gw56Uda9UH+9voVI4ELIlbH8gi713oQCsukHy+LxP8xoiM9QkH14tNAYSZhl92S6UiO3jV/zugwarGw1DWbh5n5R9Yz+J+v1U84pUkRklm1uS61qni2RZK9VScqSGFBt+/16JAuZaGIcoCvSYRopNdRBdhxoLDM5kn3YI+FJYPbzE4ZElCFkeSb3VCgbVhqSKwb/NFwLiY+WbWedm+zmDIECCWdTvtOdIKRqZ61WEVO+sRyXfWMrgqpE/2NdUzwypd7Dg+XjfHyL98zhQBXOKkm89b8knmeTer/FH0HhtLa3X6XpiHd1rSYU0TDyZWKq7HEMKIwB8gkEiXKwUw5MVfy4j2P7a44PQQlFQkx7ms9APltoUHOJXyuf5TkhxvJHFVf0aVXA/XJAlYkfnH2Q1Eqy2fl/SPaB000/SShXX8ttUt2ZwQeouPKmd3/IRYUDuXBqfSGjYr2bBdQ36X5l9sa5R/HcuaR0PYE/P7ODZSi572Yf9HGdR9ywcj45IDoDnBSjay34XO4cHEqYMVyxIRlxOMMSPCUUZuUiP8j71V/vCbQGW1fLktAtPdEv5Ht9NNciVP/Z5Y6HvSkBZ3b6yLrV5jq9Aw2ZV+lOqV6SBWkyiRtm/+Sw9r28JznZes+bJN+4ijTwcL0V81ZlR0BG5Bt5Qy72YwEfbN4AUA2J5Vc3IO0clASWpZEpZhMT5qkERcRM4SaufAL3BYCfGnX2SmZ1XVzGW6yFctjhdp00vAdpwc98dE9VSrSPtzHbWmBw5QUQ5idMSFWDeqacULCZIu6DOJIr2X5NyvTUWbWgkUPeA3/VQzO6kVXgBaos+CrDjd2ylprt/u+sbQbun9uq2EGKUSc7ZJbWSSkSvpFGms9IHT+8h5IhP28DOuRr6nMGiPmFFd4vdFhzWyqlU+mY//M/OCFOlxU+zvd6I770dmGFbHvh+QJwhJEDpD47zdlXSd5vplS57yiUU5A/dq2qy7cHBxOC/CWSzrjIAnzY8OBWe70J7liG1myiuW+vUqx2MXtGNqRZSEV2mmGBPGPOLWQOI/28+85dwHiFbUD0QVmRsJcqcIDDFJ+QvphRh/9dr+Zbi4uyvedZY8RTPpAdISvv4CXYuFVlczoLyIkhKXGHgQnHQd8K54ciCfG+OKaHd0zjo1xi+jTXtbTpjCFBRTICrNzRlxZ0XLn0tttQ46KNwGX/LWN8VSkGwidCsRc4CzQPXsuoXBEZUIKmlzSGTAKb0p/Wy5lqHICd3p3IbUa2h0UO7AtgBJPRg0tW1B2TgLksFenLbKb4AkqCtRaTFqMiQSxgEe9AU0aQACImhuEYbgL1/fXfeE8LlbFtmuMTIZxZNO6n9XmHwnK3AKJFt0T13oDQ3YXWm4kx2w1Rz7u2vRVJJ6k7//S/dUHtjtVCsclMtlfNMxlRo1Hao0aZI73nd5Y0p+WnWcXSSGZUh3pNeEc1nILBYPXp+IvXk+Ne0V547Ji5UHFxR2vxmuBkluAagVD0El0ip03MEhgnydHnO5qWTpDqdl1W2QjV/K7xxyfalYV52MxmIB0FvTfki5wyGL0cMYM2VICrn/9ALpK0zkiccvNeU9uQFO1cYYP6DmPaeIbbp7KMywbSGXz2HWsJ4pWsKtllL0klcar1p+adn2oV6OXHBl3Fe7k38E92UsJiZXxmAFogZRQgizEomXXec8ReqFZrLFtxs0OTgTQZ9pSm0KM9uMqrtqladVrCy1t58OP3ib6sD5dGt8TI2oCTrVJbX/VgXVisprZL6vLKf0MU6ZNQiMLUsGl9dIlkGOvUBcE7g9f50NVsMnbwyMnaRu0H05Sz930AJ21+kyySXC1g/aXa7kEiH5gRjfmrP98ohQ5npsfhuzUtuBAnIv3UBThPJaAsbtz0jleba7WDCt4w6p4UivfsFd9CuA54pJsr3kCTh5fz/weGiQk8UQMjUMoP2rygeUQiCtz4+bEw7Ix/ZzSkjNR9OQwRLEvfDSAAAAMktC7M62e4T2VERn6bsu3kdVSMPXhQfyAAIDjIi/iQ405qOA+WmPLPTtcWASsDTdbxkSH6O6nCl89JuSxT5B7IjoIVOewJdWdF//aJQuHeXTYjgDH4E3AFZKHCK9PrFYj+iQIJlStn1nxzniyzyvrv+elLyxSj9MvEGsn3wxC1QP0PyehWHg3KNxROZcz8qDY4NbzW7c091a2My+IVMAvS3mF7hnkiJG4qQQvmfLsQfckzSWutHTf3MIoMPJCCjuCHnWBuZ73160SkHeSz8LmmdIVXTstykrvPnDvH/w6EEkpzxXnOwj0TGIPlpS5xqEAfPGGt362pqYgBB9lnJUS8Ajv6glIePw1IZu9gXhFHXEmL+q6c0Lqzr3xk/TLhZMObgOoTkcYZPvcsUwiiCLt5q5pMmd+FTJqlyUagU/sLMFX+QK9O1B22VryJniqJiD9Dft064tCceFIrM41D7hQ0aDvV1Vkpn4uIpgwmoQHwptxi5k4CvUt426SR5goXjp/g4H+wAAAAAAAA"><div class="s">Panel Disuspend</div>
<p>Masa aktif panel ini sudah habis, jadi akses panel dikunci sementara. Perpanjang lewat Telegram, panel aktif kembali setelah pembayaran dikonfirmasi.</p>
<a href="https://t.me/csfizcloud">Perpanjang / Beli di Telegram</a>
<div class="f">Panel by FinzzHost &copy; 2026</div></div></body></html>
HTML
chown "$WEBUSER:$WEBUSER" "$VIEW"

echo "[3/5] Menyiapkan penyimpanan lisensi..."
mkdir -p "$STATE"
[ -f "$STATE/secret" ] || head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n' | cut -c1-24 > "$STATE/secret"
chown -R "$WEBUSER:$WEBUSER" "$STATE"; chmod 755 "$STATE"; chmod 644 "$STATE"/* 2>/dev/null || true

echo "[4/5] Memasang perintah 'finzzpanel'..."
cat > "$CLI" <<'CLIEOF'
#!/bin/bash
PANEL_DIR="__PANEL__"; WEBUSER="__WEBUSER__"
S="$PANEL_DIR/storage/app/finzz"; EXP="$S/expiry"; LOCK="$S/locked"; SEC="$S/secret"
art(){ (cd "$PANEL_DIR" && runuser -u "$WEBUSER" -- php artisan "$@" >/dev/null 2>&1); }
now(){ date +%s; }
fmt(){ date -d "@$1" '+%d %b %Y %H:%M'; }
save(){ echo "$1" > "$EXP"; chown "$WEBUSER:$WEBUSER" "$EXP"; chmod 644 "$EXP"; }
lock_panel(){ [ -f "$LOCK" ] && return 0
  art down --render="errors.finzz-expired" --secret="$(cat "$SEC")" --retry=3600 && { touch "$LOCK"; echo "Panel DIKUNCI (suspend)."; }; }
unlock_panel(){ art up; rm -f "$LOCK"; echo "Panel DIBUKA."; }
check(){
  if [ -f "$EXP" ] && [ "$(now)" -ge "$(cat "$EXP")" ]; then lock_panel
  else [ -f "$LOCK" ] && unlock_panel; fi; return 0; }
case "$1" in
  set)    [[ "$2" =~ ^[0-9]+$ ]] || { echo "Pakai: finzzpanel set <hari>"; exit 1; }
          save $(( $(now) + $2*86400 )); echo "Masa aktif diset $2 hari, sampai $(fmt "$(cat "$EXP")")"; check ;;
  extend) [[ "$2" =~ ^[0-9]+$ ]] || { echo "Pakai: finzzpanel extend <hari>"; exit 1; }
          base=$(now); [ -f "$EXP" ] && [ "$(cat "$EXP")" -gt "$base" ] && base=$(cat "$EXP")
          save $(( base + $2*86400 )); echo "Diperpanjang $2 hari, sampai $(fmt "$(cat "$EXP")")"; check ;;
  off)    rm -f "$EXP"; echo "Masa aktif dimatikan (tanpa batas)."; check ;;
  lock)   lock_panel ;;
  unlock) unlock_panel ;;
  check)  check ;;
  status) if [ -f "$EXP" ]; then e=$(cat "$EXP"); echo "Berlaku sampai : $(fmt "$e") (sisa $(( (e-$(now))/86400 )) hari)"; else echo "Berlaku sampai : tanpa batas"; fi
          [ -f "$LOCK" ] && echo "Status         : DIKUNCI" || echo "Status         : AKTIF"
          echo "Kode bypass owner (buka https://domain-panel/KODE saat dikunci): $(cat "$SEC")" ;;
  *) echo "finzzpanel set <hari> | extend <hari> | off | lock | unlock | status | check" ;;
esac
CLIEOF
sed -i "s|__PANEL__|$PANEL_DIR|; s|__WEBUSER__|$WEBUSER|" "$CLI"; chmod +x "$CLI"

echo "[5/5] Memasang cron auto-suspend (cek tiap 5 menit)..."
echo "*/5 * * * * root $CLI check >/dev/null 2>&1" > /etc/cron.d/finzzpanel; chmod 644 /etc/cron.d/finzzpanel
systemctl enable --now cron >/dev/null 2>&1 || true
art optimize:clear || true
echo
echo "Selesai! Contoh pemakaian:"
echo "  finzzpanel set 30      -> masa aktif 30 hari dari sekarang"
echo "  finzzpanel extend 30   -> perpanjang 30 hari"
echo "  finzzpanel status      -> lihat sisa hari + kode bypass owner"
