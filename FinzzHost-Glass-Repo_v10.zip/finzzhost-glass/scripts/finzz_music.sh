#!/bin/bash
# Pasang musik latar FinzzHost ke panel - by FinzzHost 2026
# Pakai: bash finzz_music.sh
PANEL_DIR="${PANEL_DIR:-/var/www/pterodactyl}"
WEBUSER="${WEBUSER:-www-data}"
PAGE="https://www.upload.ee/files/19846438/file.mp3.html"
DEST="$PANEL_DIR/public/finzz/music.mp3"
TMP="$DEST.tmp"

[ "$(id -u)" -eq 0 ] || { echo "Jalankan sebagai root (sudo -i)."; exit 1; }
[ -d "$PANEL_DIR/public" ] || { echo "Folder panel tidak ditemukan di $PANEL_DIR"; exit 1; }
mkdir -p "$(dirname "$DEST")"

is_audio(){
  [ -s "$1" ] || return 1
  [ "$(stat -c %s "$1")" -ge 200000 ] || return 1
  [ "$(head -c 3 "$1")" = "ID3" ] || [ "$(od -An -tx1 -N1 "$1" | tr -d ' ')" = "ff" ]
}

echo "[1/3] Mengambil link unduhan terbaru dari upload.ee..."
LINK=$(curl -sL -A "Mozilla/5.0" "$PAGE" | grep -o 'https://www.upload.ee/download/[0-9]*/[A-Za-z0-9]*/[^"'"'"' <>]*' | head -1)
[ -n "$LINK" ] || LINK="https://www.upload.ee/download/19846438/7ebdbf9bb6e32356a639/file.mp3"
echo "    $LINK"

echo "[2/3] Mengunduh..."
curl -L -A "Mozilla/5.0" -e "$PAGE" -o "$TMP" "$LINK"

if ! is_audio "$TMP"; then
  rm -f "$TMP"
  echo
  echo "Gagal: yang terunduh bukan file lagu (file mungkin sudah dihapus dari upload.ee)."
  echo "Cara manual: upload file mp3 lewat ikon klip di Termius, lalu jalankan:"
  echo "  mv \"\$(ls -t /tmp/*.mp3 | head -1)\" $DEST"
  echo "  chown $WEBUSER:$WEBUSER $DEST && chmod 644 $DEST"
  exit 1
fi

echo "[3/3] Memasang..."
mv "$TMP" "$DEST"
chown -R "$WEBUSER:$WEBUSER" "$(dirname "$DEST")"
chmod 644 "$DEST"
echo
ls -lh "$DEST"
echo "Selesai. Tes di browser: https://DOMAIN-PANEL-KAMU/finzz/music.mp3 (harus langsung memutar lagu)."
echo "Lalu buka panel, ketuk layar sekali, musik akan mulai."
