#!/bin/bash
# Rakit file .blueprint dari folder extension/ dan src/.
# Hasil: dist/finzzglass.blueprint dan dist/FinzzHost_Glass_v<mayor>.zip
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
VER=$(grep -m1 'version:' extension/conf.yml | sed 's/.*"\(.*\)".*/\1/')
TMP=$(mktemp -d)
cp -r extension/. "$TMP/"
for w in dash.wrapper.blade.php admin.wrapper.blade.php; do
  { cat src/banner.blade.php; printf '@verbatim\n<script>\n'; cat src/lang-theme.js; printf '</script>\n@endverbatim\n'; } > "$TMP/$w"
done
mkdir -p dist
rm -f dist/finzzglass.blueprint
(cd "$TMP" && zip -qr "$ROOT/dist/finzzglass.blueprint" .)
cp dist/finzzglass.blueprint "dist/FinzzHost_Glass_v${VER%%.*}.zip"
rm -rf "$TMP"
echo "Selesai: versi $VER"; ls -lh dist
