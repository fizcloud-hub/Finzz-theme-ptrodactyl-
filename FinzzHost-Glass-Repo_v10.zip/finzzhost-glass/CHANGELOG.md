# Riwayat perubahan

## 10.0.0
- Halaman status di menu extension admin: masa aktif, status akses panel, proteksi admin ID 1, dan file musik. Perintah SSH hanya tampil untuk admin ID 1.
- Repo GitHub: `build.sh`, workflow rilis otomatis, dan `scripts/logo-datauri.sh`.

## 9.0.0
- Kamus terjemahan jadi 235 entri.
- Pesan server disuspend diganti dengan arahan ke Telegram @csfizcloud, lengkap dengan tautan.
- Tombol musik menjadi redup kalau file lagu tidak ditemukan.
- Tambah `scripts/finzz_music.sh`.

## 8.0.0
- Ditulis ulang dari nol. Efek kaca dibatasi di kartu login dan modal, panel admin datar.
- Palet biru sesuai logo FinzzHost, mode gelap dan terang, kontras WCAG AA dihitung untuk kedua mode.
- Animasi berulang dihapus, kecuali bar equalizer saat musik diputar.

## 1.0.0 sampai 7.0.0
- Percobaan awal gaya neo-brutalism dan soft UI. Tidak dilanjutkan.
