@php
  $nbf = storage_path('app/finzz/expiry');
  $nbExp = (is_file($nbf)) ? (int) trim(@file_get_contents($nbf)) : 0;
  $nbLeft = $nbExp > 0 ? (int) ceil(($nbExp - time()) / 86400) : null;
  $nbLocked = is_file(storage_path('app/finzz/locked'));
  $nbProtect = class_exists('Pterodactyl\Http\Middleware\FinzzProtect');
  $nbMusic = public_path('finzz/music.mp3');
  $nbMusicOk = is_file($nbMusic);
  $nbOwner = auth()->check() && (int) auth()->id() === 1;
@endphp
<div class="row">
  <div class="col-md-8 col-md-offset-2">
    <div class="box">
      <div class="box-header with-border"><h3 class="box-title">Status FinzzHost Glass</h3></div>
      <div class="box-body no-padding">
        <table class="table">
          <tbody>
            <tr>
              <td>Masa aktif panel</td>
              <td>
                @if($nbExp > 0)
                  Sampai {{ date('d M Y H:i', $nbExp) }} (sisa {{ max($nbLeft, 0) }} hari)
                @else
                  Tanpa batas waktu
                @endif
              </td>
            </tr>
            <tr><td>Akses panel</td><td>{{ $nbLocked ? 'Dikunci (masa aktif habis)' : 'Aktif' }}</td></tr>
            <tr><td>Proteksi admin ID 1</td><td>{{ $nbProtect ? 'Terpasang' : 'Belum terpasang (jalankan finzz_setup.sh)' }}</td></tr>
            <tr>
              <td>File musik latar</td>
              <td>
                @if($nbMusicOk)
                  Ada, {{ number_format(filesize($nbMusic) / 1048576, 1) }} MB
                @else
                  Tidak ditemukan di public/finzz/music.mp3
                @endif
              </td>
            </tr>
            <tr><td>Versi tema</td><td>10.0.0</td></tr>
          </tbody>
        </table>
      </div>
      <div class="box-footer">
        <a class="btn btn-primary" href="https://t.me/csfizcloud" target="_blank" rel="noopener">Beli atau perpanjang di Telegram</a>
      </div>
    </div>
    @if($nbOwner)
    <div class="box">
      <div class="box-header with-border"><h3 class="box-title">Perintah SSH untuk pemilik</h3></div>
      <div class="box-body">
        <p>Masa aktif diatur lewat SSH supaya pembeli panel tidak bisa memperpanjang sendiri.</p>
        <p><code>finzzpanel set 30</code> mengatur masa aktif 30 hari dari sekarang</p>
        <p><code>finzzpanel extend 30</code> menambah 30 hari</p>
        <p><code>finzzpanel status</code> menampilkan sisa hari dan kode bypass</p>
        <p><code>finzzpanel off</code> mematikan batas waktu</p>
      </div>
    </div>
    @endif
  </div>
</div>
